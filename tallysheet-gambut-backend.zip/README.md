# Tallysheet Gambut Backend

Sistem backend untuk pengolahan formulir Tallysheet Gambut berbasis Node.js + Express.

## Fitur
- Menerima data formulir dari frontend.
- Menerima upload gambar sketsa lokasi dan foto lapangan.
- Menghasilkan output file Word (DOCX) sesuai dengan template Tallysheet - Gambut_2.docx.

## Cara Menjalankan
1. Clone repository.
2. Install dependency: `npm install`.
3. Jalankan server: `npm start`.

## Endpoint
POST `/api/generate-tallysheet`

---
Pastikan file template berada di folder `/template`.
