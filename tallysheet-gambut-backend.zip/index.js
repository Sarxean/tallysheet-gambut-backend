const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const PizZip = require("pizzip");
const Docxtemplater = require("docxtemplater");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());

const upload = multer({ storage: multer.memoryStorage() });

app.post("/api/generate-tallysheet", upload.any(), (req, res) => {
  try {
    const templatePath = path.join(__dirname, "template", "Tallysheet - Gambut_2.docx");
    const content = fs.readFileSync(templatePath, "binary");

    const zip = new PizZip(content);
    const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

    const dataFields = {};
    req.files.forEach(file => {
      if (file.fieldname.startsWith("fotoLapangan") || file.fieldname.startsWith("sketsa")) {
      } else {
        dataFields[file.fieldname] = file.buffer.toString();
      }
    });

    doc.setData(dataFields);
    doc.render();

    const buffer = doc.getZip().generate({ type: "nodebuffer" });
    res.set({ "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    res.send(buffer);
  } catch (error) {
    console.error(error);
    res.status(500).send("Gagal memproses dokumen.");
  }
});

app.listen(3001, () => {
  console.log("Tallysheet Backend berjalan di http://localhost:3001");
});